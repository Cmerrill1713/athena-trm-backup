# infra/event_bus.py
from collections import defaultdict
from typing import Callable, Dict, Any, List

_subs: Dict[str, List[Callable[[Dict[str, Any]], None]]] = defaultdict(list)

def subscribe(topic: str, handler: Callable[[Dict[str, Any]], None]):
    _subs[topic].append(handler)

def emit(topic: str, payload: Dict[str, Any]):
    for t, handlers in _subs.items():
        if matches(topic, t):
            for h in handlers:
                try: h({"topic": topic, **payload})
                except Exception as e: print(f"[bus] handler error on {t}: {e}")

def matches(actual: str, pattern: str) -> bool:
    # supports wildcards like "exec.*" or "release.canary.*"
    if pattern == actual: return True
    pa, aa = pattern.split("."), actual.split(".")
    if len(pa) != len(aa): return False
    return all(p == a or p == "*" for p, a in zip(pa, aa))
